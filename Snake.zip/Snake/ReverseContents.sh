cd Records/
tac Puntajes.txt > PuntajesInvertidos.txt
